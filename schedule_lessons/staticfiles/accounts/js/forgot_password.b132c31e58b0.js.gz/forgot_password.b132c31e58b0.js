$(document).ready(function() {

  $(".request-btn").on("click", function() {
    $(".submit").click();
  });

});
