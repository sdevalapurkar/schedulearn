$(document).ready(function() {

  $(".continue-btn").on("click", function() {
    $(".submit").click();
  });

});
