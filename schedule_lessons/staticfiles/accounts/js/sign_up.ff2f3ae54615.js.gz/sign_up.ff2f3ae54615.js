$(document).ready(function() {

  $(".continue-btn").click(function() {
    $(".submit").click();
  });
  
});
