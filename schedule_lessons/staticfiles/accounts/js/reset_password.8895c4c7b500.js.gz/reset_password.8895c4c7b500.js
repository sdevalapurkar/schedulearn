$(document).ready(function() {

  $(".set-password-btn").on("click", function() {
    $(".submit").click();
  });

});
