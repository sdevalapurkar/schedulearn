document.getElementById('id_username').classList.add('form-control');
document.getElementById('id_password').classList.add('form-control');
