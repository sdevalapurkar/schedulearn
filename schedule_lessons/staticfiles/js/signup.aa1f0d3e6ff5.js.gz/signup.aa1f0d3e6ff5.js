document.getElementById('id_email').autofocus = true;
document.getElementById('id_username').autofocus = false;
document.getElementById('id_username').classList.add('form-control');
document.getElementById('id_password1').classList.add('form-control');
document.getElementById('id_password2').classList.add('form-control');
document.getElementById('id_email').classList.add('form-control');
document.getElementById('id_email').required = true;